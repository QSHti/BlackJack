import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Main {

    public static void main(String[] args) {

        String inputFilePath = "resources/game_data.txt";
        String outputFilePath = "analyzer_results.txt";

        try {
            ArrayList<GameSession> gameSessions = readGameSessionsFromFile(inputFilePath);
            ArrayList<GameSession> faultySessions = findFaultySessions(gameSessions);
            writeFaultySessionsToFile(faultySessions, outputFilePath);
            System.out.println("Analysis complete. Results written to " + outputFilePath);
        } catch (IOException e) {
            System.out.println("Error: " + e.getMessage());
        }

    }

    public static ArrayList<GameSession> readGameSessionsFromFile(String filePath) throws IOException {

        ArrayList<GameSession> gameSessions = new ArrayList<>();

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            GameSession session = null;
            while ((line = reader.readLine()) != null) {
                Turn turn = Turn.parseTurn();
                if (session == null || !session.getSessionId().equals(turn.getSessionId())) {
                    // new session
                    session = new GameSession(turn.getSessionId());
                    gameSessions.add(session);
                }
                session.addTurn(turn);
            }
        }

        return gameSessions;
    }

    private static ArrayList<GameSession> findFaultySessions(ArrayList<GameSession> gameSessions) {

        ArrayList<GameSession> faultySessions = new ArrayList<>();

        for (GameSession session : gameSessions) {
            if (session.isFaulty()) {
                faultySessions.add(session);
            }
        }

        return faultySessions;
    }

    private static void writeFaultySessionsToFile(ArrayList<GameSession> faultySessions, String filePath) throws IOException {

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            for (GameSession session : faultySessions) {
                writer.write(session.toString());
                writer.newLine();
                for (Turn turn : session.getFaultyTurns()) {
                    writer.write(turn.toString());
                    writer.newLine();
                }
            }
        }

    }
    public static List<GameSession> readGameSessions(String filePath) throws IOException {
        List<GameSession> gameSessions = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader("C:/Users/dimas/Desktop/game_data_0.txt"))) {
            String line;
            GameSession currentSession = null;

            while ((line = br.readLine()) != null) {
                String[] fields = line.split(",");
                long timestamp = Long.parseLong(fields[0]);
                int sessionId = Integer.parseInt(fields[1]);
                int playerId = Integer.parseInt(fields[2]);
                String action = fields[3];
                String dealerHand = fields[4];
                String playerHand = fields[5];

                if (currentSession == null || currentSession.getSessionId() != sessionId) {
                    currentSession = new GameSession(sessionId);
                    gameSessions.add(currentSession);
                }

                Hand dealer = new Hand();
                dealer.addCards(dealerHand.split("-"));
                Hand player = new Hand();
                player.addCards(playerHand.split("-"));

                switch (action) {
                    case "P Hit":
                        player.addCard(currentSession.drawCard());
                        break;
                    case "P Stand", "D Stand":
                        break;
                    case "D Hit":
                        dealer.addCard(currentSession.drawCard());
                        break;
                    case "Reset":
                        currentSession.reset(dealer, player);
                        break;
                    default:
                        throw new IllegalArgumentException("Unknown action: " + action);
                }

                currentSession.addTurn(new Turn());
            }
        }

        return gameSessions;
    }
}

