import java.util.ArrayList;
import java.util.List;

public class Hand {
    private final List<Card> cards;

    public Hand() {
        cards = new ArrayList<>();
    }

    public void addCard(Card card) {
        cards.add(card);
    }
    Hand playerHand = new Hand();
    playerHand.addCard(new Card("S", "A", 11));
    playerHand.addCard(new Card("H", "10", 10));
    int score = playerHand.calculateScore();


    public int calculateScore() {
        int score = 0;
        boolean hasAce = false;
        for (Card card : cards) {
            int cardValue = card.getRank().getValue();
            if (cardValue == 1) {
                hasAce = true;
            }
            score += cardValue;
        }
        if (hasAce && score + 10 <= 21) {
            score += 10;
        }
        return score;
    }

    public void addCards(String[] cardStrings) {
        for (String cardString : cardStrings) {
            String[] parts = cardString.split("-");
            String suit = parts[0];
            String value = parts[1];
            int rank = Integer.parseInt(parts[2]);
            Card card = new Card(suit, value, rank);
            cards.add(card);
        }
    }


}
