import java.util.ArrayList;
import java.util.List;

public class GameSession {
    private final long gameSessionId;
    public List<Turn> turns;

    public GameSession(long gameSessionId) {
        this.gameSessionId = gameSessionId;
        this.turns = new ArrayList<>();
    }

    public void addTurn(Turn turn) {
        turns.add(turn);
    }

    public Object getSessionId() {
        return gameSessionId;
    }

    public boolean isFaulty() {
            boolean playerBusted = playerHand.getScore() > 21;
            boolean dealerBusted = dealerHand.getScore() > 21;
            boolean playerBlackjack = playerHand.getScore() == 21 && playerHand.getCards().size() == 2;
            boolean dealerBlackjack = dealerHand.getScore() == 21 && dealerHand.getCards().size() == 2;

            if (playerBusted) {
                return true;
            }

            if (dealerBusted) {
                return false;
            }

            if (playerBlackjack && dealerBlackjack) {
                return false;
            }

            if (playerBlackjack) {
                return false;
            }

            if (dealerBlackjack) {
                return true;
            }

        return playerHand.getScore() < dealerHand.getScore();
    }

    public List<Turn> getFaultyTurns() {
            List<Turn> faultyTurns = new ArrayList<>();
            for (Turn turn : turns) {
                if (turn.isFaulty()) {
                    faultyTurns.add(turn);
                }
            }
            return faultyTurns;
    }
}
