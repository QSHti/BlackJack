public class Turn {
    private long sessionId;

    public Turn() {
    }

    public static Turn parseTurn() {
        return parseTurn();
    }

    public long getSessionId() {
        return sessionId;
    }

    public boolean isFaulty() {
            if (type.equals("D Hit") && hand.getTotal() > 21) {
                return true;
            } else if (type.equals("P Hit") && hand.getTotal() > 21) {
                return true;
            } else return type.equals("D Stand") && hand.getTotal() < 17;

    }

    public void setSessionId(long sessionId) {
        this.sessionId = sessionId;
    }
}
